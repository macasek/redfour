defmodule Physics.Laws do

  def newtons_gravitational_constant do
    6.673e-11
  end

end
